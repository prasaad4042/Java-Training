package com.example.session1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Session1Application {

	public static void main(String[] args) {
		SpringApplication.run(Session1Application.class, args);
	}

}
