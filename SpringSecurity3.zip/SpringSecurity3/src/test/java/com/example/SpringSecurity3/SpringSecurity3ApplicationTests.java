package com.example.SpringSecurity3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurity3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
