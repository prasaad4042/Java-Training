package com.example.SpringSecurity3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurity3Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurity3Application.class, args);
	}

}
